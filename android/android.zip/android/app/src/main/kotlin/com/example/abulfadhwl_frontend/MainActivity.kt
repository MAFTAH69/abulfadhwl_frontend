package com.example.abulfadhwl_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
